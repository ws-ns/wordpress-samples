=== WtSurvey Wordpress Plugin ===
Contributors: wtseries
Tags: questionnaire, enquete
Requires at least: 5.2
Tested up to: 5.4.2
Requires PHP: 7.2
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

WtSurvey Wordpress Plugin is to create a questionnaire form for each posts.
The answers of visitors are saved into Wordpress database.

== Description ==

このreadmeファイルは，練習のために白木が適当に書いたものです，
信用しないように．


== Installation ==

1. From the WP admin panel, click "Plugins" -> "Add new".
2. In the browser input box, type "WtSurvey".
3. Select the "WtSurvey" plugin and click "Install".
4. Activate the plugin.

OR…

1. Download the plugin from this page.
2. Save the .zip file to a location on your computer.
3. Open the WP admin panel, and click "Plugins” -> "Add new”.
4. Click "upload”.. then browse to the .zip file downloaded from this page.
5. Click "Install”.. and then "Activate plugin”.


== Frequently asked questions ==

Q: What is this plugin.
A: This is a plugin to create a questionnaire form for each posts.


== Screenshots ==



== Changelog ==

= 0.0.3 =
  on 2020/08/26
  - バグを修正（環境依存？）

= 0.0.2 =
  on 2020/07/26
  - 前回の回答をフォームにプリセットする機能を追加
  - 設問を自由に編集する機能を開発中（メニュー追加）

= 0.0.1 =
  on 2020/07/19
  - 固定のアンケートフォーム機能をログインユーザのみに表示
  - 回答を一覧表示
  - アンケートプラグインを開発開始


== Upgrade notice ==

First version is released.


== Arbitrary section 1 ==
