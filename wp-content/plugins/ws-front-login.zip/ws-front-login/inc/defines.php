<?php
/**
 * Front Login
 *
 * @package  ws
 * @author   White Software
 *
 * @wordpress-plugin
 *
 */


// �o�[�W����
const WS_FRONT_LOGIN_PLUGIN_VERSION = '0.0.1';


?>